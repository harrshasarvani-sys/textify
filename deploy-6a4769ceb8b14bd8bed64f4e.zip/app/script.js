(() => {
  "use strict";

  // ---------------------------------------------------------------------
  // Sarvam AI config
  // ---------------------------------------------------------------------
  // ---------------------------------------------------------------------
  // Sarvam AI config (Indian languages)
  // ---------------------------------------------------------------------
  // NOTE: calling paid APIs directly from browser JS means these keys are
  // visible to anyone who opens dev tools or views the page source.
  // Fine for a local/personal tool — NOT safe to deploy publicly as-is.
  // For a public deploy, put these calls behind a small backend instead.
  const SARVAM_API_KEY = "sk_wlumbh6n_iNKFVU2N6dH2NogQ0dSPf8uV";
  const SARVAM_ENDPOINT = "https://api.sarvam.ai/speech-to-text";
  const SARVAM_MODEL = "saaras:v3";

  // ---------------------------------------------------------------------
  // ElevenLabs config (global languages — Korean, Arabic,
  // Spanish, French, Chinese, German)
  // ---------------------------------------------------------------------
  const ELEVENLABS_API_KEY = "sk_7d5ea88d405a5796a767ce831ef66b9857009bd324645812";
  const ELEVENLABS_ENDPOINT = "https://api.elevenlabs.io/v1/speech-to-text";
  const ELEVENLABS_MODEL = "scribe_v1";

  const MAX_RECORD_MS = 30000; // keep clips short & snappy across both providers

  // Indian languages — routed to Sarvam AI (saaras:v3)
  const SARVAM_LANGUAGES = [
    { code: "en-IN", label: "English", provider: "sarvam" },
    { code: "hi-IN", label: "हिन्दी · Hindi", provider: "sarvam" },
    { code: "bn-IN", label: "বাংলা · Bengali", provider: "sarvam" },
    { code: "ta-IN", label: "தமிழ் · Tamil", provider: "sarvam" },
    { code: "te-IN", label: "తెలుగు · Telugu", provider: "sarvam" },
    { code: "kn-IN", label: "ಕನ್ನಡ · Kannada", provider: "sarvam" },
    { code: "ml-IN", label: "മലയാളം · Malayalam", provider: "sarvam" },
    { code: "mr-IN", label: "मराठी · Marathi", provider: "sarvam" },
    { code: "gu-IN", label: "ગુજરાતી · Gujarati", provider: "sarvam" },
    { code: "pa-IN", label: "ਪੰਜਾਬੀ · Punjabi", provider: "sarvam" },
    { code: "od-IN", label: "ଓଡ଼ିଆ · Odia", provider: "sarvam" },
    { code: "as-IN", label: "অসমীয়া · Assamese", provider: "sarvam" },
    { code: "ur-IN", label: "اردو · Urdu", provider: "sarvam" },
    { code: "ne-IN", label: "नेपाली · Nepali", provider: "sarvam" },
    { code: "sa-IN", label: "संस्कृतम् · Sanskrit", provider: "sarvam" },
    { code: "sd-IN", label: "سنڌي · Sindhi", provider: "sarvam" },
    { code: "kok-IN", label: "कोंकणी · Konkani", provider: "sarvam" },
    { code: "ks-IN", label: "کٲشُر · Kashmiri", provider: "sarvam" },
    { code: "sat-IN", label: "ᱥᱟᱱᱛᱟᱲᱤ · Santali", provider: "sarvam" },
    { code: "mni-IN", label: "ꯃꯤꯇꯩꯂꯣꯟ · Manipuri", provider: "sarvam" },
    { code: "brx-IN", label: "बड़ो · Bodo", provider: "sarvam" },
    { code: "mai-IN", label: "मैथिली · Maithili", provider: "sarvam" },
    { code: "doi-IN", label: "डोगरी · Dogri", provider: "sarvam" },
  ];

  // Global languages — routed to ElevenLabs (scribe_v1). Codes are
  // ISO 639-1, which is what ElevenLabs' language_code param expects.
  const ELEVENLABS_LANGUAGES = [
    { code: "ko", label: "한국어 · Korean", provider: "elevenlabs" },
    { code: "ar", label: "العربية · Arabic", provider: "elevenlabs" },
    { code: "es", label: "Español · Spanish", provider: "elevenlabs" },
    { code: "fr", label: "Français · French", provider: "elevenlabs" },
    { code: "zh", label: "中文 · Chinese", provider: "elevenlabs" },
    { code: "de", label: "Deutsch · German", provider: "elevenlabs" },
  ];

  const LANGUAGES = [...SARVAM_LANGUAGES, ...ELEVENLABS_LANGUAGES];
  const LANGUAGE_MAP = Object.fromEntries(LANGUAGES.map((l) => [l.code, l]));

  const langSelect = document.getElementById("lang-select");

  function addOptions(list, groupLabel) {
    const group = document.createElement("optgroup");
    group.label = groupLabel;
    list.forEach(({ code, label }) => {
      const opt = document.createElement("option");
      opt.value = code;
      opt.textContent = label;
      group.appendChild(opt);
    });
    langSelect.appendChild(group);
  }
  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "Select a language…";
  placeholder.disabled = true;
  placeholder.selected = true;
  langSelect.appendChild(placeholder);
  addOptions(SARVAM_LANGUAGES, "Indian languages · Sarvam AI");
  addOptions(ELEVENLABS_LANGUAGES, "Global languages · ElevenLabs");
  langSelect.value = "";

  async function transcribeWithSarvam(blob, languageCode, filename = "clip.webm") {
    const formData = new FormData();
    formData.append("file", blob, filename);
    formData.append("model", SARVAM_MODEL);
    formData.append("mode", "transcribe");
    formData.append("language_code", languageCode);

    const res = await fetch(SARVAM_ENDPOINT, {
      method: "POST",
      headers: {
        "api-subscription-key": SARVAM_API_KEY,
      },
      body: formData,
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      const message =
        (data && data.error && data.error.message) ||
        data.message ||
        `Sarvam API error (${res.status})`;
      throw new Error(message);
    }

    return (data.transcript || "").trim();
  }

  async function transcribeWithElevenLabs(blob, languageCode, filename = "clip.webm") {
    const formData = new FormData();
    formData.append("file", blob, filename);
    formData.append("model_id", ELEVENLABS_MODEL);
    formData.append("language_code", languageCode);

    const res = await fetch(ELEVENLABS_ENDPOINT, {
      method: "POST",
      headers: {
        "xi-api-key": ELEVENLABS_API_KEY,
      },
      body: formData,
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      const message =
        (data && data.detail && (data.detail.message || data.detail)) ||
        data.message ||
        `ElevenLabs API error (${res.status})`;
      throw new Error(typeof message === "string" ? message : `ElevenLabs API error (${res.status})`);
    }

    return (data.text || "").trim();
  }

  async function transcribeAudio(blob, filename) {
    // startRecording() already guarantees a language was picked; this
    // fallback only guards against an unexpected empty value.
    const selected = LANGUAGE_MAP[langSelect.value] || SARVAM_LANGUAGES[0];

    if (selected.provider === "elevenlabs") {
      return transcribeWithElevenLabs(blob, selected.code, filename);
    }
    return transcribeWithSarvam(blob, selected.code, filename);
  }

  // ---------------------------------------------------------------------
  // DOM refs
  // ---------------------------------------------------------------------
  const canvas = document.getElementById("particle-canvas");
  const ctx = canvas.getContext("2d");
  const micBtn = document.getElementById("mic-btn");
  const micDock = document.querySelector(".mic-dock");
  const ringOuter = document.getElementById("ring-outer");
  const ringInner = document.getElementById("ring-inner");
  const statusEl = document.getElementById("status");
  const statusText = document.getElementById("status-text");
  const transcriptEl = document.getElementById("transcript");
  const transcriptWrap = document.querySelector(".transcript-wrap");
  const timerEl = document.getElementById("timer");
  const hintEl = document.getElementById("hint");
  const clearBtn = document.getElementById("clear-btn");
  const errorToast = document.getElementById("error-toast");
  const uploadBtn = document.getElementById("upload-btn");
  const uploadInput = document.getElementById("upload-input");

  const historyBtn = document.getElementById("history-btn");
  const historyCount = document.getElementById("history-count");
  const historyPanel = document.getElementById("history-panel");
  const historyBackdrop = document.getElementById("history-backdrop");
  const historyClose = document.getElementById("history-close");
  const historyClearAll = document.getElementById("history-clear-all");
  const historyList = document.getElementById("history-list");
  const historyEmpty = document.getElementById("history-empty");

  // ---------------------------------------------------------------------
  // History storage (IndexedDB) — saves each clip as a real .wav file
  // alongside its transcript, language, and timestamp, persisted in the
  // browser so it survives reloads. Nothing leaves the device.
  // ---------------------------------------------------------------------
  const DB_NAME = "textify-history";
  const DB_VERSION = 1;
  const STORE_NAME = "recordings";
  let dbPromise = null;

  function openHistoryDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
          store.createIndex("timestamp", "timestamp");
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function dbAdd(entry) {
    const db = await openHistoryDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).add(entry);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async function dbGetAll() {
    const db = await openHistoryDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const req = tx.objectStore(STORE_NAME).getAll();
      req.onsuccess = () => resolve(req.result.sort((a, b) => b.timestamp - a.timestamp));
      req.onerror = () => reject(req.error);
    });
  }

  async function dbDelete(id) {
    const db = await openHistoryDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async function dbClear() {
    const db = await openHistoryDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  // Decodes whatever the recorder captured (webm/opus) via the Web Audio
  // API, then encodes a standard 16-bit PCM .wav Blob from the raw
  // samples — this is what makes the saved file an actual playable .wav
  // rather than just a renamed webm file.
  async function blobToWav(blob) {
    const arrayBuffer = await blob.arrayBuffer();
    const OfflineCtx = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    const decodeCtx = new (window.AudioContext || window.webkitAudioContext)();
    let audioBuffer;
    try {
      audioBuffer = await decodeCtx.decodeAudioData(arrayBuffer.slice(0));
    } finally {
      decodeCtx.close();
    }

    const numChannels = audioBuffer.numberOfChannels;
    const sampleRate = audioBuffer.sampleRate;
    const numFrames = audioBuffer.length;

    // interleave channels
    const interleaved = new Float32Array(numFrames * numChannels);
    for (let ch = 0; ch < numChannels; ch++) {
      const channelData = audioBuffer.getChannelData(ch);
      for (let i = 0; i < numFrames; i++) {
        interleaved[i * numChannels + ch] = channelData[i];
      }
    }

    const bytesPerSample = 2; // 16-bit PCM
    const blockAlign = numChannels * bytesPerSample;
    const dataSize = interleaved.length * bytesPerSample;
    const buffer = new ArrayBuffer(44 + dataSize);
    const view = new DataView(buffer);

    const writeString = (offset, str) => {
      for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
    };

    writeString(0, "RIFF");
    view.setUint32(4, 36 + dataSize, true);
    writeString(8, "WAVE");
    writeString(12, "fmt ");
    view.setUint32(16, 16, true); // PCM chunk size
    view.setUint16(20, 1, true); // PCM format
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * blockAlign, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, 16, true); // bits per sample
    writeString(36, "data");
    view.setUint32(40, dataSize, true);

    let offset = 44;
    for (let i = 0; i < interleaved.length; i++) {
      const s = Math.max(-1, Math.min(1, interleaved[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      offset += 2;
    }

    return new Blob([buffer], { type: "audio/wav" });
  }

  function formatHistoryTime(ts) {
    const d = new Date(ts);
    return d.toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  const DOWNLOAD_ICON = `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 3V15" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M7 10L12 15L17 10" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 19H20" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>`;
  const DELETE_ICON = `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5 7H19" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M9 7V4.5C9 3.67 9.67 3 10.5 3H13.5C14.33 3 15 3.67 15 4.5V7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M7 7L7.6 19.2C7.65 20.2 8.47 21 9.47 21H14.53C15.53 21 16.35 20.2 16.4 19.2L17 7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

  async function renderHistory() {
    const entries = await dbGetAll();
    historyCount.textContent = String(entries.length);
    historyCount.hidden = entries.length === 0;

    historyList.innerHTML = "";
    if (!entries.length) {
      historyList.appendChild(historyEmpty);
      return;
    }

    entries.forEach((entry) => {
      const item = document.createElement("div");
      item.className = "history-item";

      const meta = document.createElement("div");
      meta.className = "history-item-meta";
      const time = document.createElement("span");
      time.className = "history-item-time";
      time.textContent = formatHistoryTime(entry.timestamp);
      const lang = document.createElement("span");
      lang.className = "history-item-lang";
      lang.textContent = (LANGUAGE_MAP[entry.langCode] && LANGUAGE_MAP[entry.langCode].label) || entry.langCode || "";
      meta.appendChild(time);
      meta.appendChild(lang);

      const text = document.createElement("p");
      text.className = "history-item-text";
      text.textContent = entry.text;

      const controls = document.createElement("div");
      controls.className = "history-item-controls";

      const audioUrl = URL.createObjectURL(entry.wavBlob);
      const audioEl = document.createElement("audio");
      audioEl.className = "history-item-audio";
      audioEl.controls = true;
      audioEl.src = audioUrl;
      audioEl.preload = "none";

      const downloadBtn = document.createElement("button");
      downloadBtn.className = "history-item-btn";
      downloadBtn.title = "Download .wav";
      downloadBtn.innerHTML = DOWNLOAD_ICON;
      downloadBtn.addEventListener("click", () => {
        const a = document.createElement("a");
        a.href = audioUrl;
        a.download = `textify-${entry.id}.wav`;
        document.body.appendChild(a);
        a.click();
        a.remove();
      });

      const deleteBtn = document.createElement("button");
      deleteBtn.className = "history-item-btn delete";
      deleteBtn.title = "Delete recording";
      deleteBtn.innerHTML = DELETE_ICON;
      deleteBtn.addEventListener("click", async () => {
        await dbDelete(entry.id);
        URL.revokeObjectURL(audioUrl);
        renderHistory();
      });

      controls.appendChild(audioEl);
      controls.appendChild(downloadBtn);
      controls.appendChild(deleteBtn);

      item.appendChild(meta);
      item.appendChild(text);
      item.appendChild(controls);
      historyList.appendChild(item);
    });
  }

  async function saveToHistory(wavBlob, text, langCode) {
    const entry = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      timestamp: Date.now(),
      text,
      langCode,
      wavBlob,
    };
    try {
      await dbAdd(entry);
      renderHistory();
    } catch (err) {
      showError("Couldn't save that clip to history.");
    }
  }

  function openHistoryPanel() {
    historyPanel.classList.add("open");
    historyBackdrop.classList.add("open");
    renderHistory();
  }
  function closeHistoryPanel() {
    historyPanel.classList.remove("open");
    historyBackdrop.classList.remove("open");
  }

  historyBtn.addEventListener("click", openHistoryPanel);
  historyClose.addEventListener("click", closeHistoryPanel);
  historyBackdrop.addEventListener("click", closeHistoryPanel);
  historyClearAll.addEventListener("click", async () => {
    await dbClear();
    renderHistory();
  });

  renderHistory();

  let dpr = Math.min(window.devicePixelRatio || 1, 2);
  let W = 0, H = 0;

  function resize() {
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    canvas.style.width = W + "px";
    canvas.style.height = H + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  window.addEventListener("resize", resize);
  resize();

  // ---------------------------------------------------------------------
  // Palette
  // ---------------------------------------------------------------------
  const PALETTE = ["124,92,252", "41,231,205", "236,234,245"];

  // ---------------------------------------------------------------------
  // Ambient dust particles (always drifting, react to mic volume)
  // ---------------------------------------------------------------------
  class Dust {
    constructor() {
      this.reset(true);
    }
    reset(initial) {
      this.x = Math.random() * W;
      this.y = Math.random() * H;
      this.baseR = Math.random() * 1.4 + 0.4;
      this.angle = Math.random() * Math.PI * 2;
      this.speed = Math.random() * 0.15 + 0.03;
      this.color = PALETTE[Math.floor(Math.random() * PALETTE.length)];
      this.alpha = Math.random() * 0.35 + 0.08;
      this.drift = Math.random() * 0.02 - 0.01;
      if (!initial) {
        this.x = Math.random() * W;
        this.y = H + 10;
      }
    }
    update(volume) {
      const boost = 1 + volume * 3.2;
      this.angle += this.drift;
      this.x += Math.cos(this.angle) * this.speed * boost;
      this.y += Math.sin(this.angle) * this.speed * boost - 0.06 * boost;
      if (this.y < -10) this.y = H + 10;
      if (this.x < -10) this.x = W + 10;
      if (this.x > W + 10) this.x = -10;
    }
    draw() {
      ctx.beginPath();
      ctx.fillStyle = `rgba(${this.color},${this.alpha})`;
      ctx.arc(this.x, this.y, this.baseR, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const DUST_COUNT = Math.round((W * H) / 14000);
  const dust = Array.from({ length: Math.min(DUST_COUNT, 220) }, () => new Dust());

  // ---------------------------------------------------------------------
  // Text-forming particles: sampled from rendered glyph pixels, ease from
  // a scattered origin into the shape of the words just transcribed.
  // ---------------------------------------------------------------------
  class GlyphParticle {
    constructor(tx, ty) {
      this.tx = tx;
      this.ty = ty;
      this.x = tx + (Math.random() - 0.5) * W * 0.9;
      this.y = ty + (Math.random() - 0.5) * H * 0.6 + (Math.random() - 0.5) * 200 - 40;
      this.vx = 0;
      this.vy = 0;
      this.ease = Math.random() * 0.045 + 0.05;
      this.friction = 0.82;
      this.r = Math.random() * 1.3 + 0.7;
      this.color = PALETTE[Math.floor(Math.random() * PALETTE.length)];
      this.life = 1;
    }
    update(dissolving) {
      if (dissolving) {
        this.x += this.driftX || (this.driftX = (Math.random() - 0.5) * 6);
        this.y += (this.driftY || (this.driftY = -Math.random() * 4 - 1));
        this.life -= 0.018;
        return;
      }
      const dx = this.tx - this.x;
      const dy = this.ty - this.y;
      this.vx = (this.vx + dx * this.ease) * this.friction;
      this.vy = (this.vy + dy * this.ease) * this.friction;
      this.x += this.vx;
      this.y += this.vy;
    }
    draw() {
      const a = Math.max(this.life, 0) * 0.9;
      ctx.beginPath();
      ctx.fillStyle = `rgba(${this.color},${a})`;
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  let glyphParticles = [];
  let dissolving = false;

  // Renders `text` to an offscreen canvas and samples pixel coordinates
  // that fall inside glyphs, scaled/positioned to sit over the
  // transcript area on screen.
  function spawnTextParticles(text) {
    if (!text.trim()) return;

    const rect = transcriptWrap.getBoundingClientRect();
    const maxWidth = Math.min(rect.width, 820);
    const fontSize = window.innerWidth < 640 ? 24 : 36;
    const lineHeight = fontSize * 1.3;

    const off = document.createElement("canvas");
    const octx = off.getContext("2d");
    const scale = 2; // sample at higher res for smoother letterforms
    off.width = maxWidth * scale;
    off.height = 260 * scale;
    octx.scale(scale, scale);
    octx.font = `600 ${fontSize}px "Space Grotesk", sans-serif`;
    octx.fillStyle = "#fff";
    octx.textBaseline = "top";

    // word-wrap into lines that fit maxWidth
    const words = text.split(/\s+/);
    const lines = [];
    let current = "";
    words.forEach((w) => {
      const test = current ? current + " " + w : w;
      if (octx.measureText(test).width > maxWidth && current) {
        lines.push(current);
        current = w;
      } else {
        current = test;
      }
    });
    if (current) lines.push(current);

    lines.forEach((line, i) => {
      const lineWidth = octx.measureText(line).width;
      const x = (maxWidth - lineWidth) / 2;
      octx.fillText(line, x, i * lineHeight);
    });

    const totalHeight = lines.length * lineHeight;
    const imgData = octx.getImageData(0, 0, off.width, off.height).data;

    const originX = rect.left + (rect.width - maxWidth) / 2;
    const originY = rect.top + Math.max((rect.height - totalHeight) / 2, 0);

    const stride = 3; // sample every N px for particle density/performance
    const points = [];
    for (let y = 0; y < off.height; y += stride * scale) {
      for (let x = 0; x < off.width; x += stride * scale) {
        const idx = (y * off.width + x) * 4 + 3; // alpha channel
        if (imgData[idx] > 128) {
          points.push([x / scale + originX, y / scale + originY]);
        }
      }
    }

    // cap particle count for performance on long phrases
    const MAX_PARTICLES = 2600;
    let sampled = points;
    if (points.length > MAX_PARTICLES) {
      const step = points.length / MAX_PARTICLES;
      sampled = [];
      for (let i = 0; i < MAX_PARTICLES; i++) {
        sampled.push(points[Math.floor(i * step)]);
      }
    }

    dissolving = false;
    glyphParticles = sampled.map(([px, py]) => new GlyphParticle(px, py));

    // hold the formed shape, then dissolve and reveal real (selectable) text
    clearTimeout(spawnTextParticles._holdTimer);
    spawnTextParticles._holdTimer = setTimeout(() => {
      revealRealText(text);
      dissolving = true;
      setTimeout(() => {
        glyphParticles = [];
      }, 900);
    }, 1500);
  }

  function revealRealText(segment) {
    const sep = transcriptEl.textContent.trim() ? " " : "";
    transcriptEl.textContent += sep + segment;
    transcriptEl.classList.add("visible");
  }

  // ---------------------------------------------------------------------
  // Render loop
  // ---------------------------------------------------------------------
  let currentVolume = 0; // 0..1, smoothed

  function frame() {
    ctx.clearRect(0, 0, W, H);

    dust.forEach((d) => {
      d.update(currentVolume);
      d.draw();
    });

    if (glyphParticles.length) {
      glyphParticles.forEach((p) => {
        p.update(dissolving);
        p.draw();
      });
      if (dissolving) {
        glyphParticles = glyphParticles.filter((p) => p.life > 0);
      }
    }

    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // ---------------------------------------------------------------------
  // Recording + audio analysis
  // ---------------------------------------------------------------------
  let mediaRecorder = null;
  let audioChunks = [];
  let audioCtx = null;
  let analyser = null;
  let volumeRAF = null;
  let stream = null;
  let recording = false;
  let timerInterval = null;
  let recordStart = 0;
  let autoStopTimeout = null;

  function setStatus(mode) {
    statusEl.classList.remove("listening", "processing");
    micBtn.classList.remove("listening", "processing");
    micDock.classList.remove("listening");

    if (mode === "listening") {
      statusEl.classList.add("listening");
      micBtn.classList.add("listening");
      micDock.classList.add("listening");
      statusText.textContent = "LISTENING";
      hintEl.textContent = "Tap to stop";
    } else if (mode === "processing") {
      statusEl.classList.add("processing");
      micBtn.classList.add("processing");
      statusText.textContent = "PROCESSING";
      hintEl.textContent = "Transcribing your voice";
    } else {
      statusText.textContent = "IDLE";
      hintEl.textContent = "Tap to speak";
    }
  }

  function formatTime(ms) {
    const totalSec = Math.floor(ms / 1000);
    const m = String(Math.floor(totalSec / 60)).padStart(2, "0");
    const s = String(totalSec % 60).padStart(2, "0");
    return `${m}:${s}`;
  }

  function startVolumeLoop() {
    const data = new Uint8Array(analyser.frequencyBinCount);
    const loop = () => {
      analyser.getByteFrequencyData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) sum += data[i];
      const avg = sum / data.length / 255; // 0..1
      currentVolume += (avg - currentVolume) * 0.25;

      const scale = 1 + currentVolume * 0.9;
      ringOuter.style.transform = `scale(${scale})`;
      ringInner.style.transform = `scale(${1 + currentVolume * 0.5})`;

      volumeRAF = requestAnimationFrame(loop);
    };
    loop();
  }

  function stopVolumeLoop() {
    if (volumeRAF) cancelAnimationFrame(volumeRAF);
    currentVolume = 0;
    ringOuter.style.transform = "scale(1)";
    ringInner.style.transform = "scale(1)";
  }

  async function startRecording() {
    if (!langSelect.value) {
      showError("Pick a language first — Textify no longer auto-detects.");
      langSelect.focus();
      return;
    }

    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
      showError("Microphone access was denied or unavailable.");
      return;
    }

    uploadBtn.disabled = true;

    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const source = audioCtx.createMediaStreamSource(stream);
    analyser = audioCtx.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser);
    startVolumeLoop();

    const mimeType = MediaRecorder.isTypeSupported("audio/webm")
      ? "audio/webm"
      : "";
    mediaRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    audioChunks = [];

    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) audioChunks.push(e.data);
    };
    mediaRecorder.onstop = handleRecordingStop;
    mediaRecorder.start();

    recording = true;
    recordStart = Date.now();
    timerInterval = setInterval(() => {
      timerEl.textContent = formatTime(Date.now() - recordStart);
    }, 250);

    // Sarvam's sync REST endpoint only accepts clips up to 30s
    autoStopTimeout = setTimeout(() => {
      if (recording) {
        showError("Hit the 30s limit for a single clip — stopping and sending.");
        stopRecording();
      }
    }, MAX_RECORD_MS);

    setStatus("listening");
  }

  function stopRecording() {
    if (!recording) return;
    recording = false;
    clearInterval(timerInterval);
    clearTimeout(autoStopTimeout);
    timerEl.textContent = "00:00";
    stopVolumeLoop();
    mediaRecorder.stop();
    stream.getTracks().forEach((t) => t.stop());
    if (audioCtx) audioCtx.close();
    setStatus("processing");
    micBtn.disabled = true;
    uploadBtn.disabled = true;
  }

  async function processAudioBlob(blob, filename) {
    try {
      const transcript = await transcribeAudio(blob, filename);
      if (transcript) {
        spawnTextParticles(transcript);
        try {
          const wavBlob = await blobToWav(blob);
          await saveToHistory(wavBlob, transcript, langSelect.value);
        } catch (convErr) {
          // Saving to history is best-effort — never block the main
          // transcript reveal if WAV conversion/storage fails.
          showError("Transcribed, but couldn't save this clip to history.");
        }
      } else {
        showError("Didn't catch any speech in that clip — try again.");
      }
    } catch (err) {
      showError(err.message || "Something went wrong while transcribing.");
    } finally {
      setStatus("idle");
      micBtn.disabled = false;
      uploadBtn.disabled = false;
    }
  }

  async function handleRecordingStop() {
    const blob = new Blob(audioChunks, { type: "audio/webm" });

    if (blob.size < 800) {
      // essentially silence / too short
      setStatus("idle");
      micBtn.disabled = false;
      uploadBtn.disabled = false;
      return;
    }

    await processAudioBlob(blob, "clip.webm");
  }

  micBtn.addEventListener("click", () => {
    if (recording) {
      stopRecording();
    } else {
      startRecording();
    }
  });

  // ---------------------------------------------------------------------
  // Upload-a-file flow — same transcription + history pipeline as the
  // mic, just sourced from a picked file instead of a live recording.
  // ---------------------------------------------------------------------
  const MAX_UPLOAD_BYTES = 25 * 1024 * 1024; // 25MB, generous local guard

  uploadBtn.addEventListener("click", () => {
    if (!langSelect.value) {
      showError("Pick a language first — Textify no longer auto-detects.");
      langSelect.focus();
      return;
    }
    if (recording || micBtn.disabled) return;
    uploadInput.click();
  });

  uploadInput.addEventListener("change", async () => {
    const file = uploadInput.files && uploadInput.files[0];
    uploadInput.value = ""; // allow re-selecting the same file later
    if (!file) return;

    if (!langSelect.value) {
      showError("Pick a language first — Textify no longer auto-detects.");
      langSelect.focus();
      return;
    }
    if (!file.type.startsWith("audio/") && !/\.(wav|mp3|m4a|webm|ogg|flac|aac)$/i.test(file.name)) {
      showError("That doesn't look like an audio file.");
      return;
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      showError("That file is too large — try a clip under 25MB.");
      return;
    }

    micBtn.disabled = true;
    uploadBtn.disabled = true;
    uploadBtn.classList.add("processing");
    setStatus("processing");

    try {
      await processAudioBlob(file, file.name);
    } finally {
      uploadBtn.classList.remove("processing");
    }
  });

  clearBtn.addEventListener("click", () => {
    transcriptEl.textContent = "";
    transcriptEl.classList.remove("visible");
    glyphParticles = [];
    dissolving = false;
  });

  // ---------------------------------------------------------------------
  // Error toast
  // ---------------------------------------------------------------------
  let errorTimer = null;
  function showError(msg) {
    errorToast.textContent = msg;
    errorToast.classList.add("visible");
    clearTimeout(errorTimer);
    errorTimer = setTimeout(() => {
      errorToast.classList.remove("visible");
    }, 4000);
  }

  if (!navigator.mediaDevices || !window.MediaRecorder) {
    showError("This browser doesn't support microphone recording.");
    micBtn.disabled = true;
  }
})();
