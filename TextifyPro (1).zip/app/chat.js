(() => {
  "use strict";

  // ---------------------------------------------------------------------
  // Sarvam AI config
  // ---------------------------------------------------------------------
  // NOTE: calling paid APIs directly from browser JS means these keys are
  // visible to anyone who opens dev tools, views page source, or inspects
  // the network tab. That's the same tradeoff already made elsewhere in
  // this app (see script.js). Fine for a local/personal tool — NOT safe
  // to ship to a public URL as-is. Before a public deploy, move these
  // calls behind a small backend/serverless proxy that holds the key
  // server-side, and rotate any key that has been pasted into a chat or
  // committed to a repo.
  const SARVAM_CHAT_API_KEY = "sk_0ocyxmq8_omquRXb4i5PUbDs0qa3JUrdq";
  const SARVAM_CHAT_ENDPOINT = "https://api.sarvam.ai/v1/chat/completions";
  const SARVAM_CHAT_MODEL = "sarvam-105b";

  const SARVAM_STT_API_KEY = "sk_wlumbh6n_iNKFVU2N6dH2NogQ0dSPf8uV";
  const SARVAM_STT_ENDPOINT = "https://api.sarvam.ai/speech-to-text";
  const SARVAM_STT_MODEL = "saaras:v3";

  const MAX_RECORD_MS = 20000;

  // Languages offered for the speech-to-text prompt (Sarvam STT).
  const STT_LANGUAGES = [
    { code: "en-IN", label: "English" },
    { code: "hi-IN", label: "हिन्दी · Hindi" },
    { code: "bn-IN", label: "বাংলা · Bengali" },
    { code: "ta-IN", label: "தமிழ் · Tamil" },
    { code: "te-IN", label: "తెలుగు · Telugu" },
    { code: "kn-IN", label: "ಕನ್ನಡ · Kannada" },
    { code: "ml-IN", label: "മലയാളം · Malayalam" },
    { code: "mr-IN", label: "मराठी · Marathi" },
    { code: "gu-IN", label: "ગુજરાતી · Gujarati" },
    { code: "pa-IN", label: "ਪੰਜਾਬੀ · Punjabi" },
  ];

  // ---------------------------------------------------------------------
  // DOM refs
  // ---------------------------------------------------------------------
  const sidebar = document.getElementById("chat-sidebar");
  const sidebarBackdrop = document.getElementById("chat-sidebar-backdrop");
  const sidebarOpenBtn = document.getElementById("sidebar-open");
  const sidebarCloseBtn = document.getElementById("sidebar-close");
  const newChatBtn = document.getElementById("new-chat-btn");
  const chatList = document.getElementById("chat-list");
  const chatListEmpty = document.getElementById("chat-list-empty");

  const chatTitleEl = document.getElementById("chat-title");
  const messagesEl = document.getElementById("chat-messages");
  const emptyStateEl = document.getElementById("chat-empty-state");

  const composer = document.getElementById("composer");
  const composerInput = document.getElementById("composer-input");
  const composerLangSelect = document.getElementById("composer-lang-select");
  const composerMicBtn = document.getElementById("composer-mic-btn");
  const composerSendBtn = document.getElementById("composer-send-btn");

  const voicePanel = document.getElementById("voice-panel");
  const voicePanelVisualizer = document.getElementById("voice-panel-visualizer");
  const voicePanelTimer = document.getElementById("voice-panel-timer");

  const errorToast = document.getElementById("chat-error-toast");

  // ---------------------------------------------------------------------
  // Language select for the mic prompt
  // ---------------------------------------------------------------------
  STT_LANGUAGES.forEach(({ code, label }) => {
    const opt = document.createElement("option");
    opt.value = code;
    opt.textContent = label;
    composerLangSelect.appendChild(opt);
  });
  composerLangSelect.value = "en-IN";

  // ---------------------------------------------------------------------
  // Storage — chats saved to localStorage, listed in the sidebar
  // ---------------------------------------------------------------------
  const STORAGE_KEY = "textify-chats-v1";
  const ACTIVE_KEY = "textify-active-chat-v1";

  function loadChats() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  function saveChats(chats) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(chats));
    } catch (err) {
      showError("Couldn't save chat history — storage may be full.");
    }
  }

  let chats = loadChats();
  let activeChatId = localStorage.getItem(ACTIVE_KEY) || null;

  function getActiveChat() {
    return chats.find((c) => c.id === activeChatId) || null;
  }

  function makeTitle(text) {
    const clean = text.trim().replace(/\s+/g, " ");
    return clean.length > 42 ? clean.slice(0, 42).trim() + "…" : clean || "New chat";
  }

  function formatTime(ts) {
    const d = new Date(ts);
    const now = new Date();
    const sameDay = d.toDateString() === now.toDateString();
    if (sameDay) {
      return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }
    return d.toLocaleDateString([], { month: "short", day: "numeric" });
  }

  function createNewChat() {
    const chat = {
      id: `chat_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      title: "New chat",
      messages: [],
      updatedAt: Date.now(),
    };
    chats.unshift(chat);
    activeChatId = chat.id;
    localStorage.setItem(ACTIVE_KEY, activeChatId);
    saveChats(chats);
    renderSidebar();
    renderMessages();
    composerInput.focus();
    closeSidebarOnMobile();
  }

  function selectChat(id) {
    activeChatId = id;
    localStorage.setItem(ACTIVE_KEY, activeChatId);
    renderSidebar();
    renderMessages();
    closeSidebarOnMobile();
  }

  function deleteChat(id) {
    chats = chats.filter((c) => c.id !== id);
    saveChats(chats);
    if (activeChatId === id) {
      activeChatId = chats.length ? chats[0].id : null;
      localStorage.setItem(ACTIVE_KEY, activeChatId || "");
    }
    renderSidebar();
    renderMessages();
  }

  function renderSidebar() {
    chatList.querySelectorAll(".chat-list-item").forEach((el) => el.remove());
    chatListEmpty.hidden = chats.length > 0;

    chats.forEach((chat) => {
      const item = document.createElement("div");
      item.className = "chat-list-item" + (chat.id === activeChatId ? " active" : "");
      item.innerHTML = `
        <div class="chat-list-item-text">
          <div class="chat-list-item-title"></div>
          <div class="chat-list-item-time"></div>
        </div>
        <button class="chat-list-item-delete" aria-label="Delete chat">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 7H19" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
            <path d="M9 7V5C9 4.45 9.45 4 10 4H14C14.55 4 15 4.45 15 5V7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
            <path d="M7 7L7.6 19C7.63 19.55 8.08 20 8.63 20H15.37C15.92 20 16.37 19.55 16.4 19L17 7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </button>
      `;
      item.querySelector(".chat-list-item-title").textContent = chat.title;
      item.querySelector(".chat-list-item-time").textContent = formatTime(chat.updatedAt);
      item.addEventListener("click", (e) => {
        if (e.target.closest(".chat-list-item-delete")) return;
        selectChat(chat.id);
      });
      item.querySelector(".chat-list-item-delete").addEventListener("click", (e) => {
        e.stopPropagation();
        deleteChat(chat.id);
      });
      chatList.appendChild(item);
    });
  }

  function renderMessages() {
    messagesEl.querySelectorAll(".chat-msg").forEach((el) => el.remove());
    const chat = getActiveChat();

    if (!chat || chat.messages.length === 0) {
      emptyStateEl.style.display = "";
      chatTitleEl.textContent = chat ? chat.title : "New chat";
      return;
    }

    emptyStateEl.style.display = "none";
    chatTitleEl.textContent = chat.title;
    chat.messages.forEach((msg) => appendMessageEl(msg.role, msg.content));
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function appendMessageEl(role, content, { isError = false } = {}) {
    const wrap = document.createElement("div");
    wrap.className = `chat-msg ${role}${isError ? " error" : ""}`;
    wrap.innerHTML = `
      <span class="chat-msg-role">${role === "user" ? "You" : "TextifyPro"}</span>
      <div class="chat-msg-bubble"></div>
    `;
    wrap.querySelector(".chat-msg-bubble").textContent = content;
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return wrap;
  }

  function appendTypingIndicator() {
    const wrap = document.createElement("div");
    wrap.className = "chat-msg assistant";
    wrap.id = "typing-indicator";
    wrap.innerHTML = `
      <span class="chat-msg-role">TextifyPro</span>
      <div class="chat-msg-bubble typing"><span></span><span></span><span></span></div>
    `;
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function removeTypingIndicator() {
    document.getElementById("typing-indicator")?.remove();
  }

  // ---------------------------------------------------------------------
  // Sarvam AI chat completions
  // ---------------------------------------------------------------------
  async function askSarvam(messages) {
    const res = await fetch(SARVAM_CHAT_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-subscription-key": SARVAM_CHAT_API_KEY,
      },
      body: JSON.stringify({
        model: SARVAM_CHAT_MODEL,
        messages,
      }),
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      const message = data?.error?.message || data?.message || `Sarvam chat error (${res.status})`;
      throw new Error(message);
    }

    const reply = data?.choices?.[0]?.message?.content;
    if (!reply) throw new Error("Sarvam returned an empty response.");
    return reply.trim();
  }

  async function sendMessage(text) {
    const trimmed = text.trim();
    if (!trimmed) return;

    let chat = getActiveChat();
    if (!chat) {
      chat = {
        id: `chat_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        title: "New chat",
        messages: [],
        updatedAt: Date.now(),
      };
      chats.unshift(chat);
      activeChatId = chat.id;
      localStorage.setItem(ACTIVE_KEY, activeChatId);
    }

    if (chat.messages.length === 0) {
      chat.title = makeTitle(trimmed);
    }

    chat.messages.push({ role: "user", content: trimmed });
    chat.updatedAt = Date.now();
    saveChats(chats);
    renderSidebar();
    emptyStateEl.style.display = "none";
    chatTitleEl.textContent = chat.title;
    appendMessageEl("user", trimmed);

    composerInput.value = "";
    autoResizeInput();
    setComposerBusy(true);
    appendTypingIndicator();

    try {
      const apiMessages = chat.messages.map((m) => ({ role: m.role, content: m.content }));
      const reply = await askSarvam(apiMessages);
      removeTypingIndicator();
      chat.messages.push({ role: "assistant", content: reply });
      chat.updatedAt = Date.now();
      saveChats(chats);
      renderSidebar();
      appendMessageEl("assistant", reply);
    } catch (err) {
      removeTypingIndicator();
      const message = err?.message || "Something went wrong talking to Sarvam.";
      appendMessageEl("assistant", message, { isError: true });
      showError(message);
    } finally {
      setComposerBusy(false);
      composerInput.focus();
    }
  }

  function setComposerBusy(busy) {
    composerSendBtn.disabled = busy;
    composerInput.disabled = busy;
  }

  function autoResizeInput() {
    composerInput.style.height = "auto";
    composerInput.style.height = Math.min(composerInput.scrollHeight, 160) + "px";
  }

  // ---------------------------------------------------------------------
  // Composer events
  // ---------------------------------------------------------------------
  composer.addEventListener("submit", (e) => {
    e.preventDefault();
    sendMessage(composerInput.value);
  });

  composerInput.addEventListener("input", autoResizeInput);

  composerInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(composerInput.value);
    }
  });

  newChatBtn.addEventListener("click", createNewChat);

  // ---------------------------------------------------------------------
  // Sidebar toggle (mobile)
  // ---------------------------------------------------------------------
  function openSidebar() {
    sidebar.classList.add("open");
    sidebarBackdrop.classList.add("open");
  }
  function closeSidebar() {
    sidebar.classList.remove("open");
    sidebarBackdrop.classList.remove("open");
  }
  function closeSidebarOnMobile() {
    if (window.matchMedia("(max-width: 860px)").matches) closeSidebar();
  }
  sidebarOpenBtn.addEventListener("click", openSidebar);
  sidebarCloseBtn.addEventListener("click", closeSidebar);
  sidebarBackdrop.addEventListener("click", closeSidebar);

  // ---------------------------------------------------------------------
  // Speech-to-text prompt (mic button)
  // ---------------------------------------------------------------------
  let mediaRecorder = null;
  let recordedChunks = [];
  let recordTimeout = null;
  let isRecording = false;

  // AI-voice-input-style bar visualizer, driven by a live AnalyserNode
  // (grouped frequency buckets) rather than a random/decorative pulse.
  const VIS_BAR_COUNT = 32;
  const voiceBars = Array.from({ length: VIS_BAR_COUNT }, () => {
    const bar = document.createElement("div");
    bar.className = "vp-bar";
    voicePanelVisualizer.appendChild(bar);
    return bar;
  });

  let audioCtx = null;
  let analyser = null;
  let visualizerRAF = null;
  let recordStart = 0;
  let timerInterval = null;

  function resetVoiceBars() {
    voiceBars.forEach((bar) => {
      bar.style.height = "10%";
    });
  }

  function updateVoiceBars(freqData) {
    const bucketSize = Math.floor(freqData.length / VIS_BAR_COUNT) || 1;
    for (let i = 0; i < VIS_BAR_COUNT; i++) {
      let sum = 0;
      const start = i * bucketSize;
      for (let j = 0; j < bucketSize; j++) sum += freqData[start + j] || 0;
      const avg = sum / bucketSize / 255;
      voiceBars[i].style.height = `${10 + avg * 90}%`;
    }
  }

  function formatDuration(ms) {
    const totalSec = Math.floor(ms / 1000);
    const m = String(Math.floor(totalSec / 60)).padStart(2, "0");
    const s = String(totalSec % 60).padStart(2, "0");
    return `${m}:${s}`;
  }

  function startVisualizerLoop() {
    const data = new Uint8Array(analyser.frequencyBinCount);
    const loop = () => {
      analyser.getByteFrequencyData(data);
      updateVoiceBars(data);
      visualizerRAF = requestAnimationFrame(loop);
    };
    loop();
  }

  function stopVisualizerLoop() {
    if (visualizerRAF) cancelAnimationFrame(visualizerRAF);
    resetVoiceBars();
  }

  async function transcribeWithSarvam(blob, languageCode) {
    const formData = new FormData();
    formData.append("file", blob, "prompt.webm");
    formData.append("model", SARVAM_STT_MODEL);
    formData.append("mode", "transcribe");
    formData.append("language_code", languageCode);

    const res = await fetch(SARVAM_STT_ENDPOINT, {
      method: "POST",
      headers: { "api-subscription-key": SARVAM_STT_API_KEY },
      body: formData,
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      const message = data?.error?.message || data?.message || `Sarvam STT error (${res.status})`;
      throw new Error(message);
    }

    return (data.transcript || "").trim();
  }

  async function startRecording() {
    if (isRecording) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      showError("Microphone access isn't supported in this browser.");
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      recordedChunks = [];
      mediaRecorder = new MediaRecorder(stream);

      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioCtx.createMediaStreamSource(stream);
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      startVisualizerLoop();

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunks.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        clearTimeout(recordTimeout);
        clearInterval(timerInterval);
        stopVisualizerLoop();
        if (audioCtx) audioCtx.close();
        isRecording = false;
        composerMicBtn.classList.remove("listening");
        voicePanel.hidden = true;

        if (recordedChunks.length === 0) return;
        const blob = new Blob(recordedChunks, { type: "audio/webm" });

        composerMicBtn.classList.add("processing");
        composerMicBtn.disabled = true;
        try {
          const transcript = await transcribeWithSarvam(blob, composerLangSelect.value);
          if (transcript) {
            composerInput.value = transcript;
            autoResizeInput();
            sendMessage(transcript);
          } else {
            showError("Didn't catch that — try speaking again.");
          }
        } catch (err) {
          showError(err?.message || "Couldn't transcribe that clip.");
        } finally {
          composerMicBtn.classList.remove("processing");
          composerMicBtn.disabled = false;
        }
      };

      mediaRecorder.start();
      isRecording = true;
      composerMicBtn.classList.add("listening");
      voicePanel.hidden = false;
      recordStart = Date.now();
      voicePanelTimer.textContent = "00:00";
      timerInterval = setInterval(() => {
        voicePanelTimer.textContent = formatDuration(Date.now() - recordStart);
      }, 250);
      recordTimeout = setTimeout(() => stopRecording(), MAX_RECORD_MS);
    } catch (err) {
      showError("Microphone permission was denied.");
    }
  }

  function stopRecording() {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
    }
  }

  composerMicBtn.addEventListener("click", () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  });

  // ---------------------------------------------------------------------
  // Error toast
  // ---------------------------------------------------------------------
  let toastTimeout = null;
  function showError(message) {
    errorToast.textContent = message;
    errorToast.classList.add("visible");
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => errorToast.classList.remove("visible"), 4500);
  }

  // ---------------------------------------------------------------------
  // Init
  // ---------------------------------------------------------------------
  if (!getActiveChat() && chats.length) {
    activeChatId = chats[0].id;
  }
  renderSidebar();
  renderMessages();
})();
